# Changelog

## <b>Version 0.2.0 (31/05/2025):</b>
	- added pinout for Heltec WiFi LoRa 32 v2;

## <b>Version 0.1.0 (27/05/2025):</b>
	- pinout for Heltec WiFi LoRa 32 v3;

<br><hr><p style="text-align: center;">All rights reserved. &copy; Since 2020.<br><b><a href="https://agrotechlab.lages.ifsc.edu.br/">AgroTechLab (<i>Agribusiness Technology Development Laboratory</i>)</a></b><br>
<b><a href="https://ifsc.edu.br/web/campus-lages">IFSC (<i>Federal Institute of Santa Catarina</i>) - Campus Lages</a></b><br>
225 Heitor Vila Lobos St., São Francisco<br>
Lages/SC - Brazil<br>
88506-400</p>